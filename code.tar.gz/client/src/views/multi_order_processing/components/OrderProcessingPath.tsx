import React from "react";
import { COLOR } from "../styles";

const STAGES = [
    { key: "ORDERS",    label: "Order Selection",    icon: "🛒" },
    { key: "SUPPLIERS", label: "Supplier Selection",  icon: "🏭" },
    { key: "COURIERS",  label: "Courier Selection",   icon: "🚚" },
    { key: "MANIFEST",  label: "Manifest Generation", icon: "📄" },
];

export const OrderProcessingPath: React.FC<{ activeView: string }> = ({ activeView }) => {
    const activeIndex = STAGES.findIndex((s) => s.key === activeView);

    return (
        <div style={{ marginBottom: 28 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 20 }}>
                <div>
                    <h2 style={{ margin: 0, fontSize: 22, fontWeight: 800, color: COLOR.text, letterSpacing: "-0.02em" }}>
                        Bulk Order Processing
                    </h2>
                    <p style={{ margin: "3px 0 0", fontSize: 13, color: COLOR.textMuted }}>
                        Manage orders through supplier assignment, courier selection, and manifest generation
                    </p>
                </div>
            </div>

            {/* Stepper */}
            <div style={{ display: "flex", alignItems: "center", background: COLOR.white, border: `1px solid ${COLOR.borderLight}`, borderRadius: 12, padding: "14px 20px", boxShadow: "0 2px 8px rgba(0,0,0,0.05)" }}>
                {STAGES.map((stage, i) => {
                    const done   = i < activeIndex;
                    const active = i === activeIndex;

                    const circleColor  = done ? COLOR.primary : active ? COLOR.primary : "#e2e4e9";
                    const circleBorder = done || active ? COLOR.primary : "#d0d4e0";
                    const labelColor   = active ? COLOR.primary : done ? COLOR.text : COLOR.textMuted;
                    const lineColor    = i < activeIndex ? COLOR.primary : COLOR.borderLight;

                    return (
                        <React.Fragment key={stage.key}>
                            <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 6, flex: "0 0 auto" }}>
                                <div style={{
                                    width: 36, height: 36, borderRadius: "50%",
                                    background: done || active ? circleColor : COLOR.white,
                                    border: `2px solid ${circleBorder}`,
                                    display: "flex", alignItems: "center", justifyContent: "center",
                                    fontSize: done ? 14 : 13, fontWeight: 700,
                                    color: done || active ? "#fff" : COLOR.textMuted,
                                    transition: "all 0.2s",
                                    boxShadow: active ? `0 0 0 4px rgba(0,115,234,0.15)` : "none",
                                }}>
                                    {done ? "✓" : i + 1}
                                </div>
                                <div style={{ textAlign: "center" }}>
                                    <div style={{ fontSize: 12, fontWeight: active ? 700 : 500, color: labelColor, whiteSpace: "nowrap" }}>
                                        {stage.label}
                                    </div>
                                    {done && <div style={{ fontSize: 10, color: COLOR.primary, fontWeight: 600 }}>Completed</div>}
                                    {active && <div style={{ fontSize: 10, color: COLOR.primary, fontWeight: 600 }}>In Progress</div>}
                                </div>
                            </div>
                            {i < STAGES.length - 1 && (
                                <div style={{ flex: 1, height: 2, background: lineColor, margin: "0 8px", marginBottom: 22, transition: "background 0.3s", minWidth: 24 }} />
                            )}
                        </React.Fragment>
                    );
                })}
            </div>
        </div>
    );
};
